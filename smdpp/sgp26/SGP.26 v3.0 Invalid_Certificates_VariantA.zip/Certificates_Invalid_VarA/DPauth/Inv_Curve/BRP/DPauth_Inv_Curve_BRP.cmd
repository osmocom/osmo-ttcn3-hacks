openssl ecparam –name brainpoolP192r1 –genkey –out SK_S_SM_DPauth_SIG_BRP192.pem
openssl ec –in SK_S_SM_DPauth_SIG_BRP192.pem –pubout –out PK_S_SM_DPauth_SIG_BRP192.pem

req -new -nodes -sha256 -config DPauth-csr.cnf -key SK_S_SM_DPauth_SIG_BRP192.pem -out DPauth-csrgenbrp192
x509 -req -in DPauth-csrgenbrp192 -CA CERT_DPSUBCA_VARA_SIG_BRP.pem -CAkey SK_DPSUBCA_SIG_BRP.pem -set_serial 0x231 -days 1095 -extfile DPauth-ext.cnf -out CERT_S_SM_DPauth_VARA_SIG_BRP192.pem
x509 -in CERT_S_SM_DPauth_VARA_SIG_BRP192.pem -outform DER -out CERT_S_SM_DPauth_VARC_SIG_BRP192.der
