openssl ecparam –name prime192v1 –genkey –out SK_S_SM_DPpb_SIG_NIST192.pem
openssl ec –in SK_S_SM_DPpb_SIG_NIST192.pem –pubout –out PK_S_SM_DPpb_SIG_NIST192.pem

req -new -nodes -sha256 -config DPpb-csr.cnf -key SK_S_SM_DPpb_SIG_NIST192.pem -out DPpb-csrgennist192
x509 -req -in DPpb-csrgennist192 -CA CERT_DPSUBCA_VARA_SIG_NIST.pem -CAkey SK_DPSUBCA_SIG_NIST.pem -set_serial 0x241 -days 1095 -extfile DPpb-ext.cnf -out CERT_S_SM_DPpb_VARA_SIG_NIST192.pem
x509 -in CERT_S_SM_DPpb_VARA_SIG_NIST192.pem -outform DER -out CERT_S_SM_DPpb_VARA_SIG_NIST192.der
