#!/bin/sh

if [ $# -eq 2 ]
  then
    if [ -e $1 ]
      then
        strlen=${#2}
	pos=$(( $(wc -c $1 | awk '{print $1}') - $strlen ))
        echo "Writting $2 from offset $pos..."
        printf $2 | dd of=$1 conv=notrunc bs=1 seek=$pos
      else
        echo "$0 filename string"
    fi
  else
    echo "$0 filename string"
fi